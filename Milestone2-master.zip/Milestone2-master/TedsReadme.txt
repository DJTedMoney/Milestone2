To do:

In "Server", track pellet positions.
If player collides with pellet, increase player size by one, and decrease player speed by (some value).
Then move the pellet's position to a random location on the board.

Change the server's message to add all the pellet positions to the end of it.


Fake server needs to do "find object" on the game pellets, which it can now do by name.