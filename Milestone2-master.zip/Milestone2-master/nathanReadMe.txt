TO DO LIST (as of 10:10 pm 4/22/2014)

Player Movement is finished!
 
1) Pelet consumption/player growth/pellet repositioning

<<<<<<< HEAD
2) Pellet consumption/player growth/pellet repositioning

3) Login Screen
=======
2) Login Screen
>>>>>>> d46404c54bba8b42930b76abf40a4f2279dce870
